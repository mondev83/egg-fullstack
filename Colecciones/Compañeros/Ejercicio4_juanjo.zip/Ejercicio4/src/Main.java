
import Service.peliculaService;


public class Main {

    
    public static void main(String[] args) {
        
peliculaService p1 = new peliculaService();
        p1.pelicula();
        p1.mostrarPelicula();
        p1.mayorPelicula();
        p1.duracionME();
        p1.duracionMA();
        p1.porTitulo();
        p1.porDirector();
        
        
    }
    
}
